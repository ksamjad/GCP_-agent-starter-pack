# package marker
from .agent import root_agent  # expose root_agent for convenience

__all__ = ["root_agent"]
